readme.md

Desenvolvido em:
* Mac OSX 10.13.3 
* Python 3.6.3 :: Anaconda custom (64-bit)
* OpenCV 3.3.0

Para rodar:
* `python requisito1.py`
* `python requisito1-b.py`
* `python requisito2.py`
* `python requisito3.py`
* `python requisito4.py`

Relatório:
* ./relatório/fredguth.pdf

Avisos:
* Para fechar a janela, precisa ir para a janela 'Window" e teclar ESC